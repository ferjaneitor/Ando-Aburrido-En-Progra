import random
import time
from os import system
from diction import Dictionary
from draw import HangmanDrawer

diccionare = Dictionary().diccionare
draw = HangmanDrawer()


def SelectRandomWord(DiccionareIndex):
    return random.choice(diccionare[DiccionareIndex])

system("cls")

def Main():

    continuePlaying = True

    while continuePlaying:

        Tries = 0
        max_tries = 8
        GuessedWords = 0
        
        try:
            print("Selecciona tu dificultad")
            print("1.Facil")
            print("2.Normal")
            print("3.Dificil")
            print("4.Leyenda")
            Dificulty = int(input("Ingresa aqui tu dificultad:"))
            if Dificulty == 1:
                max_tries = 10
            elif Dificulty == 2:
                Tries = 0
            elif Dificulty == 3:
                Tries = 2
            elif Dificulty == 4:
                Tries = 4
            else:
                print("Dificultad no valida")
        except:
            print("Ingresaste un valor no valido")

        SelectedWord = SelectRandomWord(Dificulty-1)
        word = SelectedWord["name"]
        definition = SelectedWord["definition"]
        guessed_letters = set()
        print("Se han adivinado", GuessedWords, " Cantidad de")
        GuessedWords+=1

        while Tries <= max_tries:

            system("cls")
            wordSpaces = " ".join([letter if letter in guessed_letters else "__" for letter in word])
            print(Tries)
            draw.print_hangman(Tries, 10)

            print("|   |     ", wordSpaces)
            
            print("")

            print("Intentos restantes:", max_tries - Tries)
            print("Letras adivinadas:", " ".join(sorted(guessed_letters)))

            if "__" not in wordSpaces:
                print("¡Felicidades! Has adivinado la palabra:", word)
                break

            if Dificulty == 1 :
                print("Pista:", definition)
                playerInput = input("Ingresa una letra para jugar: ").lower()
            
            elif Dificulty > 1:
                playerInput = input("Ingresa una letra o ""pista"" para jugar: ").lower()
            
                if playerInput == "pista":
                    print("Pista:", definition)
                    time.sleep(5)
                    continue
            
            elif Dificulty == 4:
                playerInput = input("Ingresa una letra para jugar: ").lower().strip()

            if playerInput == "":
                print("Por favor, ingresa una sola letra.")
                time.sleep(2)
                continue

            if len(playerInput) != 1 or not playerInput.isalpha():
                # print("Por favor, ingresa una sola letra.")
                # time.sleep(2)
                # continue
                if playerInput == word:
                    print("Adivinaste la palabra")
                    time.sleep(2)
                    continue
                if playerInput != word:
                    Tries += 1
                    print("Te equivocaste en adivinar la palabra")
                    time.sleep(2)
                    continue

            if playerInput in guessed_letters:
                print("Ya has adivinado esa letra.")
                time.sleep(2)
                continue

            guessed_letters.add(playerInput)

            if playerInput not in word:
                Tries += 1
                print("Incorrecto. ¡Intenta de nuevo!")
                time.sleep(2)

        if Tries == max_tries:
            print("Perdiste. La palabra era:", word)

        continuePlayingInput = input("¿Te gustaría continuar jugando? (y/n): ").lower()
        continuePlaying = continuePlayingInput == "y"

Main()
print(diccionare[1].get("definition"))